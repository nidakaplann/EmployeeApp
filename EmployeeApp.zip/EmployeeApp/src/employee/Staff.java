package employee;

	public class Staff extends Employee {
	    private int extraHours;
	    private double ratePerHour;

	    public Staff(String name, double salary, int extraHours, double ratePerHour) {
	        super(name, salary);
	        this.extraHours = extraHours;
	        this.ratePerHour = ratePerHour;
	    }

	    @Override
	    public void showInfo() {
	        System.out.println("Ad: " + getName() + ", Maaş: " + getSalary() +
	                ", Ek Mesai: " + extraHours + " saat, Ek Ücret: " + (extraHours*ratePerHour));
	    }

	    public double totalSalary() {
	        return getSalary() + extraHours*ratePerHour;
	    }
	}
