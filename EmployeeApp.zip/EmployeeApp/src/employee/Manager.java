package employee;

	public class Manager extends Employee {
	    private double bonus;

	    public Manager(String name, double salary, double bonus) {
	        super(name, salary);
	        this.bonus = bonus;
	    }

	    @Override
	    public void showInfo() {
	        System.out.println("Ad: " + getName() + ", Maaş: " + getSalary() + ", Bonus: " + bonus);
	    }

	    public double totalSalary() {
	        return getSalary() + bonus;
	    }
	}
