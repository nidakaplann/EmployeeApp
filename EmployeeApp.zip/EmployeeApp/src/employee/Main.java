package employee;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== Personel Maaş Hesaplama Programı ===");

        System.out.print("Kaç personel gireceksiniz? ");
        int n = Integer.parseInt(sc.nextLine());

        Employee[] employees = new Employee[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nPersonel " + (i + 1) + " bilgileri:");

            System.out.print("İsim: ");
            String name = sc.nextLine();

            double salary;
            while (true) {
                try {
                    System.out.print("Maaş: ");
                    salary = Double.parseDouble(sc.nextLine());
                    break;
                } catch (NumberFormatException e) {
                    System.out.println("Lütfen geçerli bir sayı girin!");
                }
            }

            Employee e = null;
            while (e == null) {
                System.out.print("Tip (Manager/Staff): ");
                String type = sc.nextLine();

                if (type.equalsIgnoreCase("Manager")) {
                    double bonus;
                    while (true) {
                        try {
                            System.out.print("Bonus: ");
                            bonus = Double.parseDouble(sc.nextLine());
                            break;
                        } catch (NumberFormatException ex) {
                            System.out.println("Lütfen geçerli bir sayı girin!");
                        }
                    }
                    e = new Manager(name, salary, bonus);

                } else if (type.equalsIgnoreCase("Staff")) {
                    int extraHours;
                    double rate;
                    while (true) {
                        try {
                            System.out.print("Ek mesai saati: ");
                            extraHours = Integer.parseInt(sc.nextLine());
                            System.out.print("Saatlik ek ücret: ");
                            rate = Double.parseDouble(sc.nextLine());
                            break;
                        } catch (NumberFormatException ex) {
                            System.out.println("Lütfen geçerli bir sayı girin!");
                        }
                    }
                    e = new Staff(name, salary, extraHours, rate);

                } else {
                    System.out.println("Geçersiz tip! Lütfen 'Manager' veya 'Staff' girin.");
                }
            }

            employees[i] = e;
        }

        // Girilen personel bilgilerini göster
        System.out.println("\n=== Girilen Personel Bilgileri ===");
        for (Employee emp : employees) {
            emp.showInfo();
            if (emp instanceof Manager) {
                System.out.println("Toplam Maaş: " + ((Manager) emp).totalSalary());
            } else if (emp instanceof Staff) {
                System.out.println("Toplam Maaş: " + ((Staff) emp).totalSalary());
            }
            System.out.println();
        }

        sc.close();
    }
}
